package com.ecom.controller;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ecom.model.Cart;
import com.ecom.model.Category;
import com.ecom.model.Product;
import com.ecom.model.UserDtls;
import com.ecom.model.transctionsDetails;
import com.ecom.service.CartService;
import com.ecom.service.CategoryService;
import com.ecom.service.ProductService;
import com.ecom.service.UserServices;
import com.ecom.util.CommonUtil;

import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class HomeController {

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private ProductService productService;

	@Autowired
	private UserServices userService;
	@Autowired
	private CartService cartServices;

	@Autowired
	private CommonUtil commonUtil;
	@Autowired
	private transctionsDetails transctionsdetails;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private JavaMailSender mailSender;

	@ModelAttribute
	public void getUserDetails(Principal p, Model m, HttpSession session) {
		if (p != null) {
			String email = p.getName();
			session.setAttribute("email", email);

			UserDtls userDtls = userService.getUserByEmail(email);
			m.addAttribute("user", userDtls);
			int id = userDtls.getId();
			System.out.println("The id of the session use is  " + id);
			session.setAttribute("userId", id);

			m.addAttribute("userId", id);
		}

		List<Category> allActiveCategory = categoryService.getAllActiveCategory();
		m.addAttribute("categorys", allActiveCategory);
	}

	@GetMapping("/")
	public String index() {
		return "index";
	}

	@GetMapping("/signin")
	public String login() {
		return "login";
	}

	@GetMapping("/register")
	public String register() {
		return "register";
	}

	@GetMapping("/products")
	public String products(Model m, @RequestParam(value = "category", defaultValue = "") String category) {
		// System.out.println("category="+category);
		List<Category> categories = categoryService.getAllActiveCategory();
		List<Product> products = productService.getAllActiveProducts(category);
		m.addAttribute("categories", categories);
		m.addAttribute("products", products);
		m.addAttribute("paramValue", category);
		return "product";
	}

	@GetMapping("/product/{id}")
	public String product(@PathVariable int id, Model m) {
		Product productById = productService.getProductById(id);
		m.addAttribute("product", productById);
		return "view_product";
	}

	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute UserDtls user, @RequestParam("img") MultipartFile file, HttpSession session)
			throws IOException {

		String imageName = file.isEmpty() ? "default.jpg" : file.getOriginalFilename();
		user.setProfileImage(imageName);
		UserDtls saveUser = userService.saveUser(user);

		if (!ObjectUtils.isEmpty(saveUser)) {
			if (!file.isEmpty()) {
				File saveFile = new ClassPathResource("static/img").getFile();

				Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + "profile_img" + File.separator
						+ file.getOriginalFilename());

//				System.out.println(path);
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			}
			session.setAttribute("succMsg", "Register successfully");
		} else {
			session.setAttribute("errorMsg", "something wrong on server");
		}

		return "redirect:/register";
	}

//	Forgot Password Code 

	@GetMapping("/forgot-password")
	public String showForgotPassword() {
		return "forgot_password.html";
	}

	@PostMapping("/forgot-password")
	public String processForgotPassword(@RequestParam String email, HttpSession session, HttpServletRequest request)
			throws UnsupportedEncodingException, MessagingException {

		UserDtls userByEmail = userService.getUserByEmail(email);

		if (ObjectUtils.isEmpty(userByEmail)) {
			session.setAttribute("errorMsg", "Invalid email");
		} else {

			String resetToken = UUID.randomUUID().toString();
			userService.updateUserResetToken(email, resetToken);

			// Generate URL :
			// http://localhost:8080/reset-password?token=sfgdbgfswegfbdgfewgvsrg

			String url = CommonUtil.generateUrl(request) + "/reset-password?token=" + resetToken;

			Boolean sendMail = commonUtil.sendMail(url, email);

			if (sendMail) {
				session.setAttribute("succMsg", "Please check your email..Password Reset link sent");
			} else {
				session.setAttribute("errorMsg", "Somethong wrong on server ! Email not send");
			}
		}

		return "redirect:/forgot-password";
	}

	@GetMapping("/reset-password")
	public String showResetPassword(@RequestParam String token, HttpSession session, Model m) {

		UserDtls userByToken = userService.getUserByToken(token);

		if (userByToken == null) {
			m.addAttribute("msg", "Your link is invalid or expired !!");
			return "message";
		}
		m.addAttribute("token", token);
		return "reset_password";
	}

	@PostMapping("/reset-password")
	public String resetPassword(@RequestParam String token, @RequestParam String password, HttpSession session,
			Model m) {

		UserDtls userByToken = userService.getUserByToken(token);
		if (userByToken == null) {
			m.addAttribute("errorMsg", "Your link is invalid or expired !!");
			return "message";
		} else {
			userByToken.setPassword(passwordEncoder.encode(password));
			userByToken.setResetToken(null);
			userService.updateUser(userByToken);
			// session.setAttribute("succMsg", "Password change successfully");
			m.addAttribute("msg", "Password change successfully");
			return "message";
		}

	}

		@GetMapping("/cart-view")
		public String cartView(Model model, HttpSession session) {
			int userId = (int) session.getAttribute("userId");
			System.out.print("The value of the session is => " + userId);
	
			List<Cart> cartList = cartServices.getAllCarts(userId);
			
//		    System.out.print("new Data is  "+);
			System.out.print("This is cart =>"+cartList);
//			System.out.println("Cart is =>"+cartLis);
//			if thir is no cart then show this page
			if(cartList.isEmpty()) {
				return "nullCart";
			}else {
				
			model.addAttribute("cart", cartList);
	
			int Total = cartServices.getTotalAmountByUserId(userId);
			
			System.out.print("The total amount of the iteam is " + Total);
			session.setAttribute("totalamount", Total);
			model.addAttribute("totalamount", Total);
			return "view-cart";
			}
	
		}
//   for increment
	@GetMapping("/view-cart/{id}")
	public String viewCart(@PathVariable("id") int productId, Model model, HttpSession session) throws Exception {
		int userId = (int) session.getAttribute("userId");
		try {
			cartServices.IncreaseQuantity(productId, userId);
		} catch (Exception e) {
			throw new Exception("Error: user id or product id not found");
		}
		System.out.println("Hello luci");
		return "redirect:/cart-view";
	}

	@GetMapping("/view-cartD/{id}")
	public String viewCarts(@PathVariable("id") int productId, Model model, HttpSession session) throws Exception {
		int userId = (int) session.getAttribute("userId");
		try {
			cartServices.DecreaseQuantity(productId, userId);
		} catch (Exception e) {
			throw new Exception("Error: user id or product id not found");
		}
		System.out.println("Hello luci");
		return "redirect:/cart-view";
	}

	@PostMapping("/successOrder")
	@ResponseBody
	public String successOrder(@RequestBody Map<String, Object> data, HttpSession session) {
		try {
			int userId = (int) session.getAttribute("userId");
			System.out.println("Order execution");

			int amount = Integer.parseInt(data.get("amount").toString());

			RazorpayClient client = new RazorpayClient("rzp_test_Nx4G4nbDhKQNDN", "QJYLfW6aouuTP9JipAB9pVvq");

			JSONObject options = new JSONObject();
			options.put("amount", amount * 100); // Multiply by 100 for INR
			options.put("currency", "INR");
			options.put("receipt", "txn_235425");

			Order order = client.orders.create(options);

			System.out.println("Order details: " + order.get("id"));
			System.out.println("Order details: " + order.get("amount"));
			session.setAttribute("order_id", order.get("id"));

//	         this is not releted to payemnt - start
//	         transctionsdetails.setOrder_id(order.get("id"));
//	         transctionsdetails.setAmount(order.get("amount"));
//	         transctionsdetails.setAddress("heaven");
//	         transctionsDetails tran = cartServices.saveTransction(transctionsdetails);

//	         end
			// Check if order creation was successful

			// Assuming `transctionsdetails` is your transaction details class or instance
			if (order != null && order.get("id") != null) {
				return order.toString();
			} else {
				return "Order creation failed!";
			}
		} catch (RazorpayException e) {
			// Log the exception details
			System.err.println("RazorpayException: " + e.getMessage());
			e.printStackTrace();
			return "Order failed!";
		}
	}

	@GetMapping("/deleteCartIteam/{productId}")
	public String deleteCartItem(@PathVariable("productId") int productId, HttpSession session,
			RedirectAttributes redirectAttributes) {
		int userId = (int) session.getAttribute("userId");
		try {
			cartServices.deleteByProductIdAndUserId(productId, userId);
			System.out.println("delete id user " + userId + "produc os " + productId);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/cart-view";
	}

	@GetMapping("/paymentSucess")
	public String successOrder() {
		return "view-cart";
	}

//	used to save data on transaction
	@GetMapping("/seccessFullPayment")
	public String seccessFullPayment(HttpSession session, Model model) {
		System.out.println("Successfull page is run");
		int id = (int) session.getAttribute("userId");
		List<Cart> cart = cartServices.seccussFullPayment(id, session, model);
		System.out.println("cart cart = " + cart);
//		 List<Cart> allProductOfUser = cartServices.selectAllCartByuserId(id, session);

//		 go through email service payment detail	
		return "redirect:/mailSender";
	}

	@Autowired
	private CommonUtil commonUtil1;

	@GetMapping("/mailSender")
	public String sendMail(HttpSession session) throws UnsupportedEncodingException, MessagingException {
		System.out.println("before");
		String email = (String)session.getAttribute("email");
		System.out.println("after"+email);
		boolean sendEmail = commonUtil1.sendSuccessMail(email,session);
		if (sendEmail) {
			System.out.println("-> Mail of payment is sent");
		}
		return "redirect:/cart-view";
	}
	@PostMapping("/changeAddress")
	public String changeAddress(@ModelAttribute transctionsDetails transctionsdetails,@RequestParam("addressChange")String addressChange,HttpSession session,RedirectAttributes redirectAttributes) {
		System.out.println("address "+addressChange); 
		session.setAttribute("addressChange", addressChange);
//		transctionsdetails.setAddress(addressChange);
        redirectAttributes.addFlashAttribute("addressChange", addressChange);

		
		return "redirect:/cart-view";
	}
}

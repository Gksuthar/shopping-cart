package com.ecom.util;

public class EmailTemplate {

    public static String getPaymentSuccessEmail(String email, String receiptDate, int amount, String paymentMode, String transactionNo, String address) {
        return "<!DOCTYPE html>" +
                "<html>" +
                "<head>" +
                "<meta charset='UTF-8'>" +
                "<title>Payment Success</title>" +
                "<style>" +
                "body { font-family: Arial, sans-serif; margin: 0; padding: 0; }" +
                ".container { width: 100%; padding: 20px; background-color: #f4f4f4; }" +
                ".receipt { background-color: #fff; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }" +
                ".header { text-align: center; margin-bottom: 20px; }" +
                ".header img { max-width: 150px; }" +
                ".header h1 { margin: 0; font-size: 24px; }" +
                ".content { margin-bottom: 20px; }" +
                ".content table { width: 100%; border-collapse: collapse; }" +
                ".content table th, .content table td { border: 1px solid #ddd; padding: 8px; text-align: left; }" +
                ".content table th { background-color: #f2f2f2; }" +
                ".footer { text-align: right; font-size: 14px; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "<div class='container'>" +
                "<div class='receipt'>" +
                "<div class='header'>" +
               
                "<h1>Payment Receipt</h1>" +
                "</div>" +
                "<div class='content'>" +
                "<table>" +
                "<tr>" +
                "<th>Email:</th><td>" + email + "</td>" +
                "</tr>" +
                "<tr>" +
                "<th>Receipt Date:</th><td>" + receiptDate + "</td>" +
                "</tr>" +
                "<tr>" +
                "<th>Address :</th><td>" + address + "</td>" +
                "</tr>" +
                "</table>" +
                "<h3>Payment Details</h3>" +
                "<table>" +
                "<tr>" +
                "<th>Sr. No.</th><th>Payment Name</th><th>Amount</th>" +
                "</tr>" +
                "<tr>" +
                "<td colspan='2'><strong>Total</strong></td><td>" + (amount + 90) + "</td>" +  // Example calculation
                "</tr>" +
                "</table>" +
                "<h3>Payment Mode</h3>" +
                "<table>" +
                "<tr>" +
                "<th>Payment Mode:</th><td>" + paymentMode + "</td>" +
                "</tr>" +
                "<tr>" +
                "<th>Transaction No.:</th><td>" + transactionNo + "</td>" +
                "</tr>" +
                "</table>" +
                "</div>" +
                "<div class='footer'>" +
                "for,Thanks for Your Order on Shopping cart" +
                "</div>" +
                "</div>" +
                "</div>" +
                "</body>" +
                "</html>";
    }
}

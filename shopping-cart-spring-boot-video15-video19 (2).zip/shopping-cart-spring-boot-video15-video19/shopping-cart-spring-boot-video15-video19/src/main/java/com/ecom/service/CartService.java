package com.ecom.service;

import java.security.Principal;
import java.util.List;

import org.springframework.ui.Model;

import com.ecom.model.Cart;
import com.ecom.model.transctionsDetails;

import jakarta.servlet.http.HttpSession;

public interface CartService {
	public Cart saveCart(Integer productId,Integer userId);
	public List<Cart> getAllCarts(Integer userId);
	public int getTotalAmountByUserId(Integer userId);
	
	public Cart IncreaseQuantity(Integer productId, Integer userId) throws Exception;
	public Cart DecreaseQuantity(Integer productId, Integer userId) throws Exception;
	
	public void deleteByProductIdAndUserId(Integer productId,Integer userID);
	
	public transctionsDetails saveTransction(transctionsDetails transctionsdetails);
	
	
	
//	public List<Cart> seccussFullPayment(Cart cart, HttpSession session);
	
	List<Cart> seccussFullPayment(int id, HttpSession session,Model model);
	
//	List<Cart> selectAllCartByuserId(int id, HttpSession session);
}

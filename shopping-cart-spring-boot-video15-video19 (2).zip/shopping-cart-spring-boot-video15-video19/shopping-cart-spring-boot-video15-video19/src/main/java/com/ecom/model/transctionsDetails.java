package com.ecom.model;

import org.springframework.stereotype.Component;
import jakarta.persistence.*;

@Entity
@Table(name = "transiction")
@Component
public class transctionsDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String address;
    private String order_id;
    private int amount;

   


    @ManyToOne
    @JoinColumn(name = "user_id")
    private UserDtls user;

    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOrder_id() {
		return order_id;
	}

	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	



	public UserDtls getUser() {
		return user;
	}

	public void setUser(UserDtls user) {
		this.user = user;
	}

	// Constructors, getters, and setters
    public transctionsDetails() {
        super();
    }

    public transctionsDetails(int id, String address, String order_id, int amount, UserDtls user) {
        super();
        this.id = id;
        this.address = address;
        this.order_id = order_id;
        this.amount = amount;
        this.user = user;
        
    }

    // Getters and Setters
    // ...
}

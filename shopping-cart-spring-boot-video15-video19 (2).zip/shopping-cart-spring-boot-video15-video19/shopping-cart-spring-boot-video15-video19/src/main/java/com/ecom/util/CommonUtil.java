package com.ecom.util;

import java.io.UnsupportedEncodingException;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.ecom.model.transctionsDetails;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Component
public class CommonUtil {
	@Autowired
	private transctionsDetails transctionsdetails;
    @Autowired
    private JavaMailSender mailSender;

    public Boolean sendMail(String url, String recipientEmail) throws UnsupportedEncodingException, MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message);

        helper.setFrom("gkstar434@gmail.com", "Shopping Cart");
        helper.setTo(recipientEmail);

        String content = "<p>Hello,</p>" + "<p>You have requested to reset your password.</p>"
                + "<p>Click the link below to change your password:</p>" + "<p><a href=\"" + url
                + "\">Change my password</a></p>";
        helper.setSubject("Password Reset");
        helper.setText(content, true);
        mailSender.send(message);
        return true;
    }

    public static String generateUrl(HttpServletRequest request) {
        String siteUrl = request.getRequestURL().toString();
        String url = siteUrl.replace(request.getServletPath(), "");
        return url;
    }
    
    public boolean sendSuccessMail(String recipientEmail, HttpSession session) throws UnsupportedEncodingException, MessagingException {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage);

      
        int amount = (int) session.getAttribute("totalamount");  
        String address = transctionsdetails.getAddress();  
        String orderId = transctionsdetails.getOrder_id();  
        String email = (String) session.getAttribute("email");  
//        String address = transctionsdetails.getAddress();
        // Generate email content using retrieved attributes
        LocalDateTime now = LocalDateTime.now();

        // Format the date and time
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = now.format(formatter);

        String content = EmailTemplate.getPaymentSuccessEmail(email, formattedDateTime, amount, "Online", orderId,address);
      
        // Set email properties and send email
        helper.setText(content, true); //true is used for the html page.
        helper.setTo(recipientEmail);
        helper.setFrom("gkstar434@gmail.com", "payment-receipt");
        helper.setSubject("Payment Receipt");

        mailSender.send(mimeMessage);
        return true;
    }

}

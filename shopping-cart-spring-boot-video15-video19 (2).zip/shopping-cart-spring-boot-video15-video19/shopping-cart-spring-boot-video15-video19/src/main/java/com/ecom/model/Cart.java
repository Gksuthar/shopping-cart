package com.ecom.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="cart")
public class Cart {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;	
    
    @ManyToOne
    private UserDtls user;
    
    private String image;
    private String name; // Renamed from productName
    private double price;
    private int qty;
    private int total_amount; // Corrected from totoal_amount
    
    @ManyToOne
    private Product product;
    
    // Constructors, getters, and setters

    public Cart() {
        super();
    }

 

    // Getters and setters

    public Cart(int id, UserDtls user, String image, String name, double price, int qty, int total_amount,
			Product product) {
		super();
		this.id = id;
		this.user = user;
		this.image = image;
		this.name = name;
		this.price = price;
		this.qty = qty;
		this.total_amount = total_amount;
		this.product = product;
	}



	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public UserDtls getUser() {
        return user;
    }

    public void setUser(UserDtls user) {
        this.user = user;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public int getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(int total_amount) {
        this.total_amount = total_amount;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    @Override
    public String toString() {
        return "Cart [id=" + id + ", user=" + user + ", image=" + image + ", name=" + name + ", product=" + product
                + ", price=" + price + ", qty=" + qty + ", total_amount=" + total_amount + "]";
    }
}

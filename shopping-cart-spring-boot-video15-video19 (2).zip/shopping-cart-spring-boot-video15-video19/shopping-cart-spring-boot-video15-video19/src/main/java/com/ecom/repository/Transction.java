package com.ecom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.model.transctionsDetails;

public interface Transction extends JpaRepository<transctionsDetails, Integer> {
	
}

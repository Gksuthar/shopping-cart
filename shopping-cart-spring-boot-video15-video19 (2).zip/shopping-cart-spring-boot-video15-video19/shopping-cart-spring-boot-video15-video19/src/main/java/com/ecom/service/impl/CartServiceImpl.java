package com.ecom.service.impl;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;

import com.ecom.model.Cart;
import com.ecom.model.Product;
import com.ecom.model.UserDtls;
import com.ecom.model.transctionsDetails;
import com.ecom.repository.CartRepository;
import com.ecom.repository.ProductRepository;
import com.ecom.repository.Transction;
import com.ecom.repository.UserRepository;
import com.ecom.service.CartService;
import com.ecom.service.UserServices;

import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;
@Service
public class CartServiceImpl implements CartService{
	
	@Autowired
	private CartRepository cartRepo;
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private ProductRepository proRepo;
	@Autowired
	private Transction Trepo;
	@Autowired
	private transctionsDetails transctionsdetails;
	
	@Override
	public Cart saveCart(Integer productId, Integer userId) {
	    // Retrieve user and product details
	    UserDtls userDtls = userRepo.findById(userId).orElse(null);
	    System.out.println("The user details = " + userDtls);
//	    product detail are used to setDiscountprice
	    Product productDetails = proRepo.findById(productId).orElse(null);
	    String productName = productDetails.getTitle();
	    double price= productDetails.getDiscountPrice();
	    System.out.println("The product details = " + productDetails);

	    // Check if user or product is not found
	    if (userDtls == null || productDetails == null) {
	        throw new RuntimeException("User or Product not found");
	    }

	    Cart existingCart = cartRepo.findByProductIdAndUserId(productId, userId);
	    
	    Cart cart;

	    if (ObjectUtils.isEmpty(existingCart)) {
	        cart = new Cart();
	        cart.setProduct(productDetails);
	        cart.setUser(userDtls);
	        cart.setQty(1);
	        cart.setPrice(productDetails.getDiscountPrice());
	        cart.setName(productName);
	        cart.setPrice(productDetails.getDiscountPrice());
	        cart.setTotal_amount((int) price);
	    } 
//	   if cart is already exist then we are increse quantity 
	    else {
	        existingCart.setQty(existingCart.getQty()+1);
	        existingCart.setTotal_amount((int) (existingCart.getQty() * productDetails.getDiscountPrice()));
//	       update the cart cart and save only change in both = setQty and setTotal_amount and  alll data replace on cart well as already exist in db same it is
	        cart = existingCart;
	    }

	    // Save the cart entry
	    return cartRepo.save(cart);
	}



	@Override
	 public List<Cart> getAllCarts(Integer userId) {
//        List<Cart> cart =  
        		return cartRepo.getAllCartsByUserId(userId);
	}



	@Override
    public int getTotalAmountByUserId(Integer userId) {
        return cartRepo.getTotalAmountByUserId(userId);
    }



	@Override
	public Cart IncreaseQuantity(Integer productId, Integer userId) throws Exception {
	
			
			System.out.println("The 1Suer id is "+userId);
			System.out.println("The 1PRoduct id is "+productId);
			UserDtls userDtls  = userRepo.findById(userId).orElseThrow(()->new Exception("User not found"));
			Product preoduct = proRepo.findById(productId).orElseThrow(()->new Exception("product not found"));
		 	System.out.println("The 2Suer id is "+userDtls);
		 	System.out.println("The 2PRoduct id is "+preoduct);
			 Cart cart = cartRepo.findByProductIdAndUserId(productId, userId);
			 Product productDetails = proRepo.findById(productId).orElse(null);
		 
			
			  if(ObjectUtils.isEmpty(cart)) {
				  throw new Exception("Error: user not found Exception");
			  }
			  else{
				 cart.setQty(cart.getQty()+1);
				 System.out.println("Increase value is "+cart.getQty());
				 cart.setTotal_amount((int) (cart.getQty() * productDetails.getDiscountPrice()));
		 }
		 return cartRepo.save(cart);
//		return 0;
	}
	@Override
	public Cart DecreaseQuantity(Integer productId, Integer userId) throws Exception {
		
		
		System.out.println("The 1Suer id is "+userId);
		System.out.println("The 1PRoduct id is "+productId);
		UserDtls userDtls  = userRepo.findById(userId).orElseThrow(()->new Exception("User not found"));
		Product preoduct = proRepo.findById(productId).orElseThrow(()->new Exception("product not found"));
		System.out.println("The 2Suer id is "+userDtls);
		System.out.println("The 2PRoduct id is "+preoduct);
		Cart cart = cartRepo.findByProductIdAndUserId(productId, userId);
		Product productDetails = proRepo.findById(productId).orElse(null);
		
		
		if(ObjectUtils.isEmpty(cart)) {
			throw new Exception("Error: user not found Exception");
		}
		else{
			int qnty = cart.getQty();
			if(qnty>1) {
				
				cart.setQty(cart.getQty()-1);
				System.out.println("Increase value is "+cart.getQty());
				cart.setTotal_amount((int) (cart.getQty() * productDetails.getDiscountPrice()));
			}else {
				System.out.print(" productId"+productId +"UserId :"+userId+"Hello");
				cartRepo.deleteByProductIdByUserId(productId, userId);
				
				
//		        throw new Exception("Error: Quantity cannot be less than 1");
			}
		}
		return cartRepo.save(cart);
	}



	@Override
    @Transactional
    public void deleteByProductIdAndUserId(Integer productId, Integer userId) {
        cartRepo.deleteByProductIdByUserId(productId, userId);
    }



	@Override
	public transctionsDetails saveTransction(transctionsDetails transctionsdetails) {
		return Trepo.save(transctionsdetails);
	}



//	@Override
//	public List<Cart> seccussFullPayment(Cart cart,HttpSession session) {
//		
//	// TODO Auto-generated method stub
//		int id = (int) session.getAttribute("userId");
//		UserDtls userDtls = userRepo.findById(id).get();
//		List<Cart>userCart = cartRepo.getAllCartsByUserId(id);
//		System.out.println("List of cary "+userCart);
//		return userCart;
//		
//	}
	@Override
	public List<Cart> seccussFullPayment(int id,HttpSession session,Model model) {
		List<Cart>userCart = cartRepo.getAllCartsByUserId(id);
		
		List<Cart> cartsId = cartRepo.findAll();
		UserDtls user = userRepo.findById(id).get();
		
		
//		Product product = userRepo.findById(id).get();
		// transctionsdetails.setAddress("haven");
		System.out.println("before amount ");
		int amount = (int)session.getAttribute("totalamount");
		System.out.println("after amount "+amount);
		
		transctionsdetails.setUser(user);
		transctionsdetails.setAmount(amount);
//		transctionsdetails.setCart(userCart);
		String order_id = (String) session.getAttribute("order_id");
		System.out.println("Order id "+order_id);
		transctionsdetails.setOrder_id(order_id);
		System.out.println("userCaris =>"+userCart);
		String address = (String)session.getAttribute("addressChange");
		transctionsdetails.setAddress(address);
		model.addAttribute("address", address);
		Trepo.save(transctionsdetails);
		return userCart;
	}



//	@Override
//	public List<Cart> selectAllCartByuserId(int id,HttpSession session) {
//		// TODO Auto-generated method stub
//
////	    public List<Cart> selectAllCartByUserId(int userId, HttpSession session) {
//	        List<Cart> carts = cartRepo.findByUserId(id);
//	        System.out.println("All Carts: " + carts);
//
//	        Product productId = (Product) session.getAttribute("pid");
////	        transctionsdetails transactionDetails = new TransactionDetails();
//	        transctionsdetails.setProduct(productId);
//	        Trepo.save(transctionsdetails);
//
//	        return carts;
//	}


	
	
	
	
	
}
package com.ecom.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ecom.model.Cart;
import com.ecom.model.transctionsDetails;

import jakarta.transaction.Transactional;

@Repository
public interface CartRepository extends JpaRepository<Cart,Integer>{
	public Cart findByProductIdAndUserId(Integer productId,Integer userId);

	public List<Cart> getAllCartsByUserId(Integer userId);
		
	 @Query("SELECT SUM(c.total_amount) FROM Cart c WHERE c.user.id = :userId")
	 int getTotalAmountByUserId(Integer userId);
	 
	 @Query("UPDATE Cart c SET c.qty = c.qty + 1 WHERE c.product.id = :productId AND c.user.id = :userId")
	 int increaseQty(@Param("productId") Integer productId, @Param("userId") Integer userId);
	 
	 @Query("UPDATE Cart c SET c.qty = c.qty - 1 WHERE c.product.id = :productId AND c.user.id = :userId")
	 int decreaseQty(@Param("productId") Integer productId, @Param("userId") Integer userId);
	
	 	@Modifying
	    @Transactional
	    @Query("DELETE FROM Cart c WHERE c.product.id = :productId AND c.user.id = :userId")
	    void deleteByProductIdByUserId(@Param("productId") Integer productId, @Param("userId") Integer userId);
//	 @Query("SELECT c FROM Cart c WHERE c.product.id = :productId")
//	 List<Cart> getAllCartByProductId()
//	 List<Cart>findByProductId(Integer id);
	    @Query("SELECT c FROM Cart c WHERE c.user.id = :userId")
		List<Cart> findByUserId(@Param("userId") int userId);
	    
	    
	    @Modifying
	    @Transactional
	    @Query("DELETE FROM Cart c WHERE c.product.id = :productId")
	    void deleteByProductId(@Param("productId") int productId);
		 
}

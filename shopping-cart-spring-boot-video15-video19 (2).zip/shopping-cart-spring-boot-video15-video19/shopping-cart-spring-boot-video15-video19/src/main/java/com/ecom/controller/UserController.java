package com.ecom.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecom.model.Cart;
import com.ecom.model.Category;
import com.ecom.model.Product;
import com.ecom.model.UserDtls;
import com.ecom.service.CartService;
import com.ecom.service.CategoryService;
import com.ecom.service.ProductService;
import com.ecom.service.UserServices;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserServices userService;
	@Autowired
	private CategoryService categoryService;
	@Autowired
	private CartService cartService;

	@Autowired
	private ProductService prodService;
	@GetMapping("/")
	public String home() {
		return "user/home";
	}

	@ModelAttribute
	public void getUserDetails(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			UserDtls userDtls = userService.getUserByEmail(email);
			m.addAttribute("user", userDtls);
		}

		List<Category> allActiveCategory = categoryService.getAllActiveCategory();
		m.addAttribute("categorys", allActiveCategory);
	}
	@GetMapping("/saveProductToCart")
	public String saveProductToCarts(@RequestParam Integer uid, @RequestParam Integer pid, HttpSession session, Model model) {
	    // Save the product to the cart
	    Cart saveCart = cartService.saveCart(pid, uid);
	    
	    // Retrieve the product by ID
	    Product productById = prodService.getProductById(pid);
	   session.setAttribute("pid", productById); 
	    model.addAttribute("product", productById);
	    
	    if (ObjectUtils.isEmpty(saveCart)) {
	        session.setAttribute("errorMsg", "Product not added to cart");
	    } else {
	        session.setAttribute("succMsg", "Product added to cart");
	    }
	    
	    return "view_product";
	}
	@GetMapping("/changeAddress")
	public String changeAddress() {
		return "user/changeAddress";
	}

}

function paymentStart() {
    var amount = $(".amount").text().trim(); 
    console.log(amount);
    if (!amount || amount === "") {
        alert("Amount is required");
        return;
    }
// send a request on server for creating 
$.ajax({
    url: '/successOrder',
    method: 'POST',
    contentType: 'application/json',
    data: JSON.stringify({ amount: amount, info: 'order_request' }),
    dataType: 'json',
    success: function(response) {	
        if (response.status === 'created') {
            var options = {
                key: 'rzp_test_Nx4G4nbDhKQNDN', 
                amount: response.amount,
                currency: 'INR',
                name: 'shopping-cart',
                description: 'payment',
                order_id: response.id,
                handler: function(response) {
                    /*console.log(response.razorpay_payment_id);
                    console.log(response.razorpay_order_id);
                    console.log("signuture is = "+response.razorpay_signature);*/
                    alert("Payment successful!");
                    window.location.href = '/seccessFullPayment';
                    
                },
                prefill: {
                    name: "", // Populate with actual data if needed
                    email: "", // Populate with actual data if needed
                    contact: "" // Populate with actual data if needed
                },
                notes: {
                    address: "ganesh suthar is my note"
                },
                theme: {
                    color: "#3399cc"
                }
            };
            var rzp1 = new Razorpay(options);
            rzp1.on('payment.failed', function(response) {
                alert("Oops! Payment failed.");
            });
            rzp1.open();
        } else {
            alert('Failed to create order!');
        }
    },
    error: function(xhr, status, error) {
        alert('Error creating order: ' + error);
    }
});

}
